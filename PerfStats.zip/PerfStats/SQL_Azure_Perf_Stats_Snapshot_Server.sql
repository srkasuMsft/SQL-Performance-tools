SET NOCOUNT ON

IF (CHARINDEX ('11.0', @@VERSION) = 0) BEGIN
  PRINT ''
  PRINT '**** NOTE ****'
  PRINT '**** This script is for SQL Server Azure.  Errors are expected when run on earlier versions.'
  PRINT '**************'
  PRINT ''
END
ELSE BEGIN
  PRINT 'This script captures a one-time snapshot of Windows Azure SQL Database logical server wide information.'
  PRINT 'It is to be executed only once during collector shutdown '
  PRINT '[SERVER]_SQL_Azure_Perf_Stats_Snapshot_Server.OUT'
  PRINT ''
END
GO


RAISERROR (' ', 0, 1) WITH NOWAIT
RAISERROR ('-- sys.database_connection_stats --', 0, 1) WITH NOWAIT
select * from sys.database_connection_stats
where start_time >= CAST(FLOOR(CAST(getdate() AS float)) AS DATETIME)
order by start_time desc

RAISERROR (' ', 0, 1) WITH NOWAIT
RAISERROR ('-- sys.event_log --', 0, 1) WITH NOWAIT
select database_name, start_time, end_time, event_category, event_type, event_subtype, event_subtype_desc, 
severity, 
event_count, 
REPLACE( REPLACE (REPLACE (description, CHAR(13), ' '), CHAR(10), ' '), CHAR(09), '') 'Description', 
REPLACE( REPLACE (REPLACE (cast(additional_data as nvarchar(4000)), CHAR(13), ' '), CHAR(10), ' '),CHAR(09),'')  'additional_data' 
from sys.event_log
where event_type <> 'connection_successful'
and start_time >= CAST(FLOOR(CAST(getdate() AS float)) AS DATETIME)
order by start_time desc
