[CmdletBinding()]
Param(
	[Parameter(Mandatory=$True,Position=1)]
	[string]$serverName,
	
	[Parameter(Mandatory=$True,Position=2)]
	[string]$databaseName,
	
	[Parameter(Mandatory=$True,Position=3)]
	[string]$userName,
	
	[Parameter(Mandatory=$True,Position=4)]
	[string]$password
)

if(-Not (Test-Path output))
{
	New-Item -ItemType directory -Path output
}

$timeJump = 2

while ($timeJump -le 256)
{
	$startDate = Get-Date
	
	$arg1 = "-S"+$serverName
	$arg2 = "-U"+$userName+"@"+$serverName
	$arg3 = "-P"+$password
	$arg4 = "-d"+$databaseName
	$arg5 = "-w4000"
	$arg6 = "-iSQL_Azure_Perf_Stats.sql"
	$arg7 = "-ooutput\"+$serverName+"_SQL_Azure_Perf_Stats_"+$startDate.ToString("MMddyyyyHHmmss")+".out"
	
	$argString = @($arg1, $arg2, $arg3, $arg4, $arg5, $arg6, $arg7)
	
	echo "Starting SQL Data Capture..."
	& sqlcmd.exe $argString	
	echo $LASTEXITCODE
	echo "Waiting $timeJump seconds..."
	Start-Sleep -s $timeJump
	
	if((Get-Date) -ge $startDate.AddSeconds(30))
	{
		echo "Retry Time Reset"
		$timeJump = 2
	} Else {
		$timeJump = $timeJump * 2
	}
}