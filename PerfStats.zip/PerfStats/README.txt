/***** README.TXT *****/
Follow the instructions below to collect Perf Stats script output from your Sql Azure database

1) Pre-requisities:- For this collection to work correctly you need to have 
    * Sql login that has access to both the user database and master database
    * Name of your database server - typically in the format of xyz.windows.database.net
    * Verify your system has SQL Server tools installed. specifically sqlcmd.exe should be available. In the command line, type sqlcmd.exe. if it says "is not recognized as an internal or external command", you need to locate sqlcmd.exe and add it to path environement variable.

2) After unzipping the files, you should see the following files apart from this README.txt
	PerfStats.txt
	PerfStatsSnap.txt
	SQL_Azure_Perf_Stats.sql
	SQL_Azure_Perf_Stats_Snapshot.sql
	SQL_Azure_Perf_Stats_Snapshot_Server.sql

3) Rename PerfStatsSnap.txt to PerfStatsSnap.cmd and PerfStats.txt to PerfStats.ps1

4) Allow access for the powershell script to run on your device by setting your Execution policy to Unrestricted during the time frame (http://technet.microsoft.com/en-us/library/ee176961.aspx)

4) When issue occurs, run powershell.exe -file PerfStats.ps1 from command prompt and let it run for 15 minutes.

6) Next run PerfStatsSnap.cmd which will generate a one time snapshot of some system tables

PerfStatsSnap.cmd [servername] [username] [password] [dbname]

7) Afterwards, you will have three *.out files generated in a directory named output. if they are small enough, just email. if they are big, zip them up & let me know so that I can provide you location to transfer.

	SQL_Azure_Perf_Stats_abc.database.windows.net.out
	SQL_Azure_Perf_Stats_Snapshot_abc.database.windows.net.out
	SQL_Azure_Perf_Stats_Snapshot_Server_abc.database.windows.net.out
Please zip up the files into a single zip file. If the zip file is less than 5 MB than you can usually send it via email.If the size is greateer than 5 MB please contact the support professional to provide you with an FTP site where you can upload this data.
